// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const https = require("https");
const request = require('request');
var source_trip = "";

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function GetdestinationdetailsHandler(agent){
     var source = agent.parameters.source;
      if(!source){
      	source = "portland, OR";
      }
    source_trip = source;
    const destination = agent.parameters.destination;
  	return distanceAPI(source,destination)
        .then(chat => {
          agent.add(chat + "are you planning to travel by road or by air ? ");
        })
        .catch(() => {
          agent.add(`I'm sorry.`);
        });
  
  }
  
    function GettransportdetailsHandler(agent){
    const transport = agent.parameters.carrental;
    const context = agent.getContext('awaiting_destination');
      var location = source_trip;
      if(!location){
      	location = "portland ,OR";
      }
    return PlacesAPI(transport[0],location)
        .then(chat => {
          agent.add(chat);
        })
        .catch(() => {
          agent.add(`I'm sorry.`);
       });
  }
  
  	function travelbookingHandler(agent){
  		 const context = agent.getContext('awaiting_transportmode');
      	 let travel_mode = context.parameters.carrental;
      	 let usr_res = agent.parameters.userresponse;
      	 const context_dest = agent.getContext('awaiting_destination');
      	  let destination = context.parameters.destination;
      	 if (!usr_res) {
           usr_res = "yes";
         }
         	if(usr_res == "no" || usr_res == "nope"){
            	agent.add(" Is there anything else i can help with ? ");
            }
      else {
           usr_res = "yes";
      	 if(travel_mode.includes("car") || travel_mode.includes("road") || travel_mode.includes("drive")) {
           agent.add("your rental car of type Sedan booking is confirmed at " + destination + " Do you want to search hotels in " + destination );
         }
      	else {
        	agent.add(" Your ticket from " + source_trip + " to " + destination + " is confirmed. Carrier id - 756 run by Jetairlines seat number 13A." + " Do you want to search hotels in " + destination );
        }
      }
  	}
    function PlacesAPI(transport,location){
    const url = "https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input="+transport+","+location+"&inputtype=textquery&fields=formatted_address,name,opening_hours,rating&locationbias=circle:2000&key=AIzaSyD7lnEvqoaQdFXqFBiZEscDWopMQLKaA0I";
      return new Promise((resolve, reject) => {
        https.get(url, function(resp) {
          var json = "";
          resp.on("data", function(chunk) {
            console.log("received JSON response: " + chunk);
            json += chunk;
          });

          resp.on("end", function() {
            let jsonData = JSON.parse(json);
            let chat = "";
           if(transport.includes("car") || transport.includes("road") || transport.includes("drive")) {
            chat = " available car rentals are " + jsonData.candidates[0].name + " with user rating as " + jsonData.candidates[0].rating + " located at " + jsonData.candidates[0].formatted_address + " Which type of car do you want ? ";
            }
            else {
             chat = " Near by airport is " + jsonData.candidates[0].name + " with user rating as " + jsonData.candidates[0].rating + " located at " + jsonData.candidates[0].formatted_address + " Do you want to book a ticket ?";
            }
            resolve(chat);
          });
        });
      });
    }
  
    function distanceAPI(source,destination) {
    const url = "https://maps.googleapis.com/maps/api/directions/json?origin="+source+"&destination="+destination+"&key=AIzaSyDsUZbwZQf7DVeRyxiUxveG5uWXLJ3HS_c";
      return new Promise((resolve, reject) => {
        https.get(url, function(resp) {
          var json = "";
          resp.on("data", function(chunk) {
            console.log("received JSON response: " + chunk);
            json += chunk;
          });

          resp.on("end", function() {
            let jsonData = JSON.parse(json);
           let chat = "The distance is " + jsonData.routes[0].legs[0].distance.text + " by road it takes " + jsonData.routes[0].legs[0].duration.text + " to " + jsonData.routes[0].legs[0].end_address;
            resolve(chat);
          });
        });
      });
    }
  
  
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }

  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('Getdestinationdetails', GetdestinationdetailsHandler);
  intentMap.set('Gettransportdetails', GettransportdetailsHandler);
  intentMap.set('travelbooking', travelbookingHandler);
 agent.handleRequest(intentMap);
});
